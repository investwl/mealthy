import React, { useState, useEffect } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import * as Font from 'expo-font';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Checkbox from 'expo-checkbox'; //  <--  Import Checkbox

const NutritionCard = () => {
  const [fontsLoaded, setFontsLoaded] = useState(false);
  const [nutritionData, setNutritionData] = useState([]);
  const [currentCard, setCurrentCard] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const baseUrl = "http://localhost:3000";
  const [isChecked, setIsChecked] = useState(false); //  <--  State untuk checkbox


  useEffect(() => {
    const loadResources = async () => {
      try {
        await Font.loadAsync({
          'PlusJakartaSans-VariableFont_wght': require('./assets/fonts/PlusJakartaSans-VariableFont_wght.ttf'),
        });
        setFontsLoaded(true);
      } catch (error) {
        console.error('Error loading fonts:', error);
      }
      fetchData();
    };

    loadResources();
  }, []);

    const fetchData = async () => {
        setIsLoading(true);
        try {
        const response = await fetch(`${baseUrl}/api/nutrition`);  // Ganti dengan IP address dan port yang benar
        const data = await response.json();

        if (Array.isArray(data) && data.length > 0) {
            // Filter kartu yang sudah dilihat hari ini
            const filteredData = await filterSeenCards(data);

            if (filteredData.length > 0) {
            // Pilih kartu secara acak dari yang sudah difilter
            const randomIndex = Math.floor(Math.random() * filteredData.length);
            setCurrentCard(filteredData[randomIndex]);
            } else {
            setCurrentCard(null); // Tidak ada kartu yang bisa ditampilkan
            }
        } else {
            console.warn("No nutrition data or invalid format received.");
            setCurrentCard(null);
        }
        } catch (error) {
            console.error('Error fetching data:', error);
            setCurrentCard(null);
            Alert.alert('Error', 'Failed to load nutrition data.');
        } finally {
            setIsLoading(false);
        }
    };

    const filterSeenCards = async (data) => {
        const today = new Date();
        today.setHours(0, 0, 0, 0); // Set ke awal hari
        const filteredData = [];

        for (const card of data) {
        const lastShown = await AsyncStorage.getItem(`nutrition_card_${card.id}_lastShown`);
        if (!lastShown || new Date(lastShown).getTime() < today.getTime()) {
            filteredData.push(card); // Tambahkan kartu jika belum pernah dilihat atau sudah lewat hari ini
        }
        }
        return filteredData;
    };

  const handleDontShowAgain = async (id) => {
   try {
      // Kirim Permintaan ke Server
      const response = await fetch(`${baseUrl}/api/nutrition/${id}/dontshow`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

        const data = await response.json(); // Dapatkan respons dari server

        if (data.success) {
            console.log('Preference saved successfully!');
            // Refresh data (ambil ulang dari server)
            fetchData(); // Panggil fetchData untuk me-refresh
        } else {
            console.error('Failed to save preference:', data);
        }
        } catch(error) {
        console.error('Error saving preference:', error);
        Alert.alert('Error', 'Failed to save preference.'); // Tambahkan alert
        }
  };

  if (!fontsLoaded || isLoading) {
    return <ActivityIndicator size="large" color="#0000ff" />;
  }

  if (!currentCard) {
    return <View style={{ flex: 1 }}></View>; // Tampilan kosong jika tidak ada kartu
  }

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <View style={styles.headerContainer}>
          <View style={styles.header}>
            <Text style={styles.title}>{currentCard.title}</Text>
            <TouchableOpacity style={styles.closeButtonContainer} onPress={() => handleDontShowAgain(currentCard.id)}>
                <View style={styles.closeButton}>
                <Text style={styles.closeText}>×</Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.imageWrapper}>
          <Image
            source={{ uri: currentCard.image }}
            style={[styles.image, styles.imageContainer]}
          />
        </View>
        <Text style={styles.description}>{currentCard.description}</Text>
        <View style={styles.list}>
          {currentCard.list.map((item, index) => (
            <Text key={index} style={styles.listItem}>
              {item}
            </Text>
          ))}
        </View>
        <Text style={styles.tip}>{currentCard.tip}</Text>

        {/* Checkbox dan Label */}
        <View style={styles.checkboxContainer}>
          <Checkbox
            value={isChecked}
            onValueChange={(newValue) => {
                setIsChecked(newValue);
                if (newValue) {
                    handleDontShowAgain(currentCard.id);
                }
            }}
            color={isChecked ? '#4630EB' : undefined} // Warna opsional
          />
          <Text style={styles.checkboxLabel}>Don't show me again today</Text>
        </View>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#E5E5E5',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingTop: 70,
    paddingBottom: 70,
  },
  card: {
    backgroundColor: '#F8F8E8',
    borderRadius: 10,
    width: '90%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
    flexGrow: 1,
    marginBottom: 20,
  },
  headerContainer: {
    width: '100%',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    overflow: 'hidden',
    marginTop: -20,
    height: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: '#A6B37D',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
    flex: 1,
    fontFamily: 'PlusJakartaSans-VariableFont_wght',
  },
 closeButtonContainer: {
        padding: 5,
        backgroundColor: '#CC5C5C',  //  <--  Pindahkan backgroundColor ke sini
        borderRadius: 15,          //  <--  Pindahkan borderRadius ke sini
        width: 30,
        height: 30,
        justifyContent: 'center',
        alignItems: 'center',
    },
  closeButton: {
      backgroundColor: '#CC5C5C',  //<--  Hapus ini
      borderRadius: 15,      //<--  Hapus ini
      width: 30,             // <--  Hapus ini
      height: 30,            // <--  Hapus ini
      justifyContent: 'center',// <--  Hapus ini
      alignItems: 'center',  // <--  Hapus ini
  },
  closeText: {
      fontSize: 20,
      color: '#FFFFFF',
  },
  imageWrapper: {
    alignItems: 'center',
  },
  image: {
    width: '90%',
    height: 250,
    resizeMode: 'contain',
    marginVertical: 10,
  },
  imageContainer: {
    borderRadius: 10,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.7,
    shadowRadius: 8,
    elevation: 5,
  },
  description: {
    fontSize: 23,
    color: '#567100',
    textAlign: 'center',
    marginVertical: 10,
    fontFamily: 'PlusJakartaSans-VariableFont_wght',
    fontWeight: 'bold',
    marginHorizontal: 20,
  },
  list: {
    marginVertical: 10,
    paddingHorizontal: 40,
  },
  listItem: {
    fontSize: 16,
    color: '#567100',
    marginVertical: 2,
    fontFamily: 'PlusJakartaSans-VariableFont_wght',
    textAlign: 'center',
  },
  tip: {
    fontSize: 16,
    color: '#567100',
    fontStyle: 'italic',
    marginVertical: 10,
    fontFamily: 'PlusJakartaSans-VariableFont_wght',
    marginHorizontal: 35,
    textAlign: 'center',
  },
  checkboxContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center', //  Atur ke tengah
        marginTop: 10,        //  Beri jarak dari konten di atasnya
        marginBottom: 10,     // Tambahkan margin bottom
    },
    checkboxLabel: {
        marginLeft: 8,      //  Beri jarak antara checkbox dan label
        fontSize: 16,
        color: '#333',
        fontFamily: 'PlusJakartaSans-VariableFont_wght',
    },

});

export default NutritionCard;