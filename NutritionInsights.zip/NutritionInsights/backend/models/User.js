// models/User.js
'use strict';
// Hapus: const sequelize = require('.').sequelize;

// Ubah menjadi function yang menerima sequelize
module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false,
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    firstName: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    profileImage: {
        type: DataTypes.STRING,
        allowNull: true,
    },
}, {
    modelName: 'User',
    tableName: 'Users',
});

User.associate = (models) => {
// User.hasMany(models.Post, { foreignKey: 'userId', as: 'posts' });
// User.hasMany(models.Comment, { foreignKey: 'userId', as: 'comments' });
// User.hasMany(models.Like, { foreignKey: 'userId', as: 'likes' });
User.belongsToMany(models.Nutrition, {
    through: models.UserNutrition,
    foreignKey: 'userId',
    otherKey: 'nutritionId',
    as: 'nutritionInsights'
  });
};
  return User;
};