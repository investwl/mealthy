// server.js
const express = require('express');
const { Op } = require('sequelize');
const cors = require('cors'); // Pastikan cors diimport
// Impor sequelize dari db.js, BUKAN dari models/index.js
const sequelize = require('./db'); // Perhatikan path yang benar
const models = require('./models');
const Nutrition = models.Nutrition;
const User = models.User;
const UserNutrition = models.UserNutrition;
const multer = require('multer');
const path = require('path');


const app = express();
const port = 3000;


// Konfigurasi CORS
const corsOptions = {
  origin: 'http://localhost:8081', //  <--  ISI DENGAN URL FRONTEND KAMU!
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'], //  <--  Tambahkan method yang kamu gunakan
  allowedHeaders: ['Content-Type', 'Authorization'], //  <--  Tambahkan header yang kamu gunakan
};
app.use(cors(corsOptions)); //  <--  Gunakan middleware cors dengan konfigurasi di atas

// --- Middleware ---
app.use(express.json());
app.use(express.static('public'));

// --- JWT Secret (TIDAK DIGUNAKAN UNTUK SEMENTARA, tapi biarkan sebagai komentar) ---
// const JWT_SECRET = 'your-super-secret-key'; // CHANGE THIS!

// --- Simulasi Authentication (HAPUS ATAU KOMENTARI, TIDAK DIPERLUKAN UNTUK SEMENTARA) ---
// ... (kode middleware authenticate yang lama) ...


// --- Konfigurasi Multer ---
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images/');
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, file.fieldname + '-' + uniqueSuffix + ext);
    }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = ['.jpg', '.jpeg', '.png', '.gif'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
        cb(null, true);
    } else {
        cb(new Error('Invalid file type.'));
    }
};

const upload = multer({
    storage,
    fileFilter,
    limits: { fileSize: 5 * 1024 * 1024 } // 5MB
}).single('image');

// --- Routes ---

// Hapus endpoint login (tidak diperlukan untuk saat ini)
// app.post('/api/login', ...);

// GET - Ambil data nutrisi (TANPA authenticate)
app.get('/api/nutrition', async (req, res) => {
  try {
    //  Simulasi User ID (Ganti ini nanti saat Anda menambahkan autentikasi)
    const userId = 1;  // Contoh: Anggap user ID 1 selalu login
    // const userId = req.user.id; // Ini yang seharusnya, saat ada autentikasi

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const allNutrition = await Nutrition.findAll({
      order: [['createdAt', 'DESC']],
    });

    const filteredNutrition = [];
    for (const nutrition of allNutrition) {
        const userNutrition = await UserNutrition.findOne({
          where: {
            userId: userId,
            nutritionId: nutrition.id
          }
        });

        if (!userNutrition || !userNutrition.lastShown || userNutrition.lastShown.getTime() < today.getTime()) {
          const updatedNutrition = nutrition.toJSON();
          updatedNutrition.image = `${req.protocol}://${req.get('host')}${nutrition.image}`;
          filteredNutrition.push(updatedNutrition);
        }
    }
    res.json(filteredNutrition);
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).json({ message: 'Error fetching data', error: error.message });
  }
});

// POST - Simpan preferensi "don't show again" (TANPA authenticate)
app.post('/api/nutrition/:id/dontshow', async (req, res) => {
  try {
      const today = new Date();
    const { id } = req.params;
    // Simulasi User ID (Ganti ini nanti saat Anda menambahkan autentikasi)
    const userId = 1;
    // const userId = req.user.id // Ini yang seharusnya, saat ada autentikasi


    const nutrition = await Nutrition.findByPk(id);
    if (!nutrition) {
      return res.status(404).json({ message: 'Nutrition card not found' });
    }

    const [userNutrition, created] = await UserNutrition.findOrCreate({
      where: { userId, nutritionId: id },
      defaults: { lastShown: today },
    });

    if (!created) {
      await userNutrition.update({ lastShown: today });
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Error saving preference:', error);
    res.status(500).json({ message: 'Error saving preference', error: error.message });
  }
});

// POST - Menambah Nutrition Insight baru (TANPA authenticate)
app.post('/api/nutrition', (req, res) => { // Perhatikan ini
    upload(req, res, async (err) => {
        if (err) {
            if (err instanceof multer.MulterError) {
                return res.status(400).json({ message: err.message });
            }
            return res.status(500).json({ message: err.message });
        }

        try {
            const { title, description, list, tip } = req.body;
            const imagePath = req.file ? '/images/' + req.file.filename : null;

            if (!title || !description || !list || !tip || !imagePath) {
                return res.status(400).json({ message: 'All fields are required' });
            }

            let parsedList;
            try {
                parsedList = JSON.parse(list);
                if (!Array.isArray(parsedList) || !parsedList.every(item => typeof item === 'string')) {
                    throw new Error('Invalid list format');
                }
            } catch (error) {
                return res.status(400).json({ message: 'Invalid list format. Must be a JSON array of strings.' });
            }

            const newNutrition = await Nutrition.create({
                title,
                image: imagePath,
                description,
                list: parsedList,
                tip,
            });

            const updatedNutrition = newNutrition.toJSON();
            updatedNutrition.image = `${req.protocol}://${req.get('host')}${newNutrition.image}`;
            res.status(201).json(updatedNutrition);

        } catch (error) {
            console.error('Error creating nutrition:', error);
            res.status(500).json({ message: 'Error creating nutrition', error: error.message });
        }
    });
});

// --- Error Handling Middleware (Global) ---
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

// --- Start Server ---
sequelize.authenticate()
  .then(() => {
    console.log('Connection to the database has been established successfully.');
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });