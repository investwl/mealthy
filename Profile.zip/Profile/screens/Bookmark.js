// screens/Bookmark.js
import React from 'react';
import { View, Text } from 'react-native';

const BookmarkScreen = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Bookmark Screen</Text>
    </View>
  );
};

export default BookmarkScreen;