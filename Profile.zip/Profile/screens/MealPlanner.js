// screens/MealPlanner.js
import React from 'react';
import { View, Text } from 'react-native';

const MealPlannerScreen = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Meal Planner Screen</Text>
    </View>
  );
};

export default MealPlannerScreen;
