// app.js
const express = require('express');
const app = express();
const cors = require('cors');
const userRoutes = require('./backend/routes/userRoutes');
require('dotenv').config();
const path = require('path');

// Middleware
// Opsi CORS yang lebih permisif (hanya untuk development!)
app.use(cors()); // Izinkan semua origins.  Ini TIDAK DIREKOMENDASIKAN untuk production.

// Opsi CORS yang lebih aman (untuk production)
// const corsOptions = {
//   origin: 'http://localhost:3000', // Ganti dengan URL frontend Anda
//   optionsSuccessStatus: 200 // Beberapa legacy browser (IE11, beberapa SmartTV) choke on 204
// }
// app.use(cors(corsOptions));


app.use(express.json({ limit: '10mb' }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public'))); // Pastikan path ini benar

// Routes
app.use('/users', userRoutes);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server berjalan di port ${PORT}`);
});